export default [
  require('C:\\Repos\\my-website\\node_modules\\infima\\dist\\css\\default\\default.css'),
  require('C:\\Repos\\my-website\\node_modules\\@docusaurus\\theme-classic\\lib\\prism-include-languages'),
  require('C:\\Repos\\my-website\\node_modules\\@docusaurus\\theme-classic\\lib\\nprogress'),
  require('C:\\Repos\\my-website\\src\\css\\custom.css'),
];
